import os
from django.shortcuts import render
from . import PoolDict

def Login(request):
    return render(request,'Login.html')


def CheckAdminLogin(request):

    try:
        emailid = request.POST['emailid']
        password = request.POST['password']
        db, cmd = PoolDict.CollectionPool()
        q = "select * from admins where emailid='{}' and password='{}'".format(emailid, password)

        cmd.execute(q)
        result = cmd.fetchone()

        if (result):

            return render(request, "Dashboard.html", {'result': result})
        else:
            return render(request, "Login.html", {'result': result, 'msg': 'Invalid Userid or Password'})

        db.close()
    except Exception as e:
          print(e)

          return render(request, "Login.html", {'result': {}, 'msg': 'Server Error'})

